# Jump Rocket 🚀

Minimalistinis Godot 3.5 žaidimas su Android eksportavimo palaikymu.

## 📱 Kaip gauti APK

1. Įkelk šį projektą į **GitHub**.
2. Eik į **Actions** skiltį.
3. Paleisk workflow rankiniu būdu (`Build Godot Android APK`).
4. Atsisiųsk sugeneruotą **jumprocket.apk** iš Artifacts.

## 🛠 Naudojama
- [Godot Engine 3.5.3](https://godotengine.org)
- GitHub Actions (automatiniam build)